/*Paulo Soares de Moura, Adenilson Almeida*/
CREATE DATABASE db_prova;