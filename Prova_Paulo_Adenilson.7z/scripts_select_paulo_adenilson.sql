/*SELECT P.pergunta
FROM pergunta as P
WHERE P.id;*/

/*SELECT R.resposta 
FROM resposta as R
WHERE R.id;*/

/*SELECT P.pergunta, R.resposta 
FROM pergunta as P
, resposta as R
WHERE P.id = R.pergunta_id;*/

/*SELECT aluno.id, aluno.nome
FROM aluno;*/

/*SELECT prova.id, disciplina
FROM prova;*/