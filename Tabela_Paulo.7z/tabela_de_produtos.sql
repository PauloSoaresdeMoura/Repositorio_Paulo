USE db_agregacao;
INSERT INTO produto(Cod_prod, Cod_clas, Tipo_prod, Nome_prod, Qtd_prod, Val_prod)
VALUES(028, 10, 'Telefonia', 'Celular', 20, '3.500,00');

INSERT INTO produto(Cod_prod, Cod_clas, Tipo_prod, Nome_prod, Qtd_prod, Val_prod)
VALUES(029, 10, 'Telefonia', 'Carregador', 40, '50,00');

INSERT INTO produto(Cod_prod, Cod_clas, Tipo_prod, Nome_prod, Qtd_prod, Val_prod)
VALUES(030, 10, 'Telefonia', 'Chip', 25, '20,00');